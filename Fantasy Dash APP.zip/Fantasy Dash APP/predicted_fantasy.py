from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
import pandas as pd

def predict_next_fantasy_point(df):
    predictions = []
    
    improvement_factor = 1.15
    # Ensure the input data is sorted by 'Year' for proper chronological order
    df = df.sort_values(by=['PLAYER', 'Year'])
    
    for player_name in df['PLAYER'].unique():
        # Filter data for the specific player
        player_data = df[df['PLAYER'] == player_name].copy()
        df_recent = df[df['Year'] == '2023-24']
        
        #If player doesn't have enough data, predict using the most recent season's score and an improvement factor
        if len(player_data) < 2:
            most_recent_points = player_data['Fantasy Points'].iloc[-1]
            next_year_prediction = most_recent_points * improvement_factor
            
        else:
            # Create the 'NextYearPoints' column (target)
            player_data['NextYearPoints'] = player_data['Fantasy Points'].shift(-1)
            
            # Drop the last row 
            player_data = player_data.dropna()
            
            #Ensure there's enough data left after dropping NaNs
            if len(player_data) < 2:
                most_recent_points = player_data['Fantasy Points'].iloc[-1]
                next_year_prediction = most_recent_points * improvement_factor
                continue
            
            #Define X (features) and y (target)
            X = player_data['Fantasy Points'].values.reshape(-1, 1)
            y = player_data['NextYearPoints'].values
            
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
            
            # Initializing and training the model 
            model = LinearRegression()
            model.fit(X_train, y_train)
            
            last_year_points = player_data['Fantasy Points'].iloc[-1]
            next_year_prediction = model.predict([[last_year_points]])[0]
            
        #figuring out what team they were on so that we can conjoin the dataframes for future manipulating
        most_recent_team = df_recent[df_recent['PLAYER'] == player_name]
        
        if most_recent_team.empty:
            most_recent_team = None  
        else:
            most_recent_team = most_recent_team['TEAM'].iloc[-1]
        
        #append the prediction to the list along with the most recent team
        predictions.append({'PLAYER': player_name, 'Pred Fantasy Points': next_year_prediction, 'TEAM': most_recent_team})
    
    predictions_df = pd.DataFrame(predictions)
    predictions_df['Year'] = '2024-25'
    next_year_points = predictions_df.sort_values(by='Pred Fantasy Points', ascending=False).reset_index(drop=True)
    
    return next_year_points


