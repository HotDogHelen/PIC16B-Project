import pandas as pd
def team_analysis(current_df, team):
    #Filter dataframe for the selected team
    team_df = current_df[current_df['TEAM'] == team]
    team_df = team_df[team_df['Year'] == '2023-24']

    #Calculate team-wide stats
    team_performance = {
        'Total Players': len(team_df['PLAYER'].unique()),
        'Average Fantasy Points': team_df['Fantasy Points'].mean(),
        'Total Fantasy Points': team_df['Fantasy Points'].sum()
    }

    return team_performance


def team_graph_df(current_df,pred_df, team1, team2):
    
    result = pd.DataFrame()
        
    # group by Year and Team and sum the Fantasy Points
    team1_points = current_df[current_df['TEAM'] == team1].groupby('Year')['Fantasy Points'].sum().reset_index()
    team2_points = current_df[current_df['TEAM'] == team2].groupby('Year')['Fantasy Points'].sum().reset_index()
    
    team1_points.columns = ['Year', 'Team1 Total Fantasy Points']
    team2_points.columns = ['Year', 'Team2 Total Fantasy Points']
    
    #Merge the two DataFrames on Year
    result = pd.merge(team1_points, team2_points, on='Year', how='outer')
    result = result.sort_values('Year').reset_index(drop=True)
    
    def predicted_row(pred_df, team1, team2):
      
        team1_unique_df = pred_df[pred_df['TEAM'] == team1].drop_duplicates(subset='PLAYER')
        team2_unique_df = pred_df[pred_df['TEAM'] == team2].drop_duplicates(subset='PLAYER')
    
        
        team1p_points = team1_unique_df['Pred Fantasy Points'].sum()
        team2p_points = team2_unique_df['Pred Fantasy Points'].sum()
        
     # Create prediction row
        pred_row = pd.DataFrame({
            'Year': ['2024-25'],
            'Team1 Total Fantasy Points': team1p_points,
            'Team2 Total Fantasy Points': team2p_points
        })
        
        return pred_row
    
    if 'Pred Fantasy Points' in pred_df.columns:
        pred_row = predicted_row(pred_df,team1,team2)
        result = pd.concat([result, pred_row], ignore_index=True)

        
        return result

